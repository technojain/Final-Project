import { StyleSheet } from 'react-native';
import Constants from 'expo-constants';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#f194ff',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight + 30,
  },
  title: {
    color: '#3D1273',
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 15,
    alignSelf: 'center',
  },
  item: {
    width: '100%',
    fontSize: 12,
    paddingVertical: 10,
    paddingLeft: 18,
    borderRadius: 8,
    marginTop: 30,
    backgroundColor: '#f194ff',
  },
  info: {
    color: '#FFF',
    fontSize: 16,
    alignSelf: 'baseline',
    borderBottomColor: '#00F0FF',
    marginBottom: 30,
  },
});
