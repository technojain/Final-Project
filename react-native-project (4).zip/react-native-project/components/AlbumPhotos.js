import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text, Image } from 'react-native-elements';
import React from 'react';
import { styles } from './style';

const AlbumPhotos = ({ route, navigation, data }) => {
  const { id } = route.params;

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerBackTitle: 'Albums',
      headerTitle: 'Album Photos',
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigation]);

  const renderItem = ({ item }) => (
    <View>
      <Text style={styles.title}>{item.title}</Text>
      <View>
        <Image source={{ uri: item.thumbnail }} />
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Album Photos</Text>
      <FlatList
        style={{ width: '100%' }}
        data={data.filter(({ albumId }) => albumId === id)}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

export default AlbumPhotos;
