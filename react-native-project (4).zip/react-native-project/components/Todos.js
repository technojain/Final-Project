import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text } from 'react-native-elements';
import React from 'react';
import { styles } from './style';

const AlbumList = ({ navigation, data }) => {
  const renderItem = ({ item }) => (
    <View>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ flex: 1, height: 1, backgroundColor: 'black' }} />
        <View>
          <Text style={{ width: 50, textAlign: 'center' }}>{item.id}</Text>
        </View>
        <View style={{ flex: 1, height: 1, backgroundColor: 'black' }} />
      </View>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.info}>Status: {item.completed ? "Completed" : "Not Completed"}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>To Do List</Text>
      <FlatList
        style={{ width: '100%' }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

export default AlbumList;
