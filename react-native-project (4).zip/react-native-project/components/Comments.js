import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text } from 'react-native-elements';
import React from 'react';
import axios from 'axios';
import { styles } from './style';

const Comments = ({ route, navigation }) => {
  const { id } = route.params;
  const [data, setData] = React.useState(null);

  const fetchData = async () => {
    await axios
      .get(`https://jsonplaceholder.typicode.com/posts/${id}/comments`)
      .then((res) => setData(res.data))
      .catch((err) => alert(err));
  };

  React.useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerBackTitle: 'Story',
      headerTitle: 'Comments',
    });
  }, [navigation]);

  const renderItem = ({ item }) => (
    <View>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ flex: 1, height: 1, backgroundColor: 'black' }} />
        <View>
          <Text style={{ width: 50, textAlign: 'center' }}>{item.id}</Text>
        </View>
        <View style={{ flex: 1, height: 1, backgroundColor: 'black' }} />
      </View>
      <Text style={styles.title}>{item.name}</Text>
      <Text style={styles.info}>{item.email}</Text>
      <Text style={styles.info}>{item.body}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Comments List</Text>
      <FlatList
        style={{ width: '100%' }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

export default Comments;
