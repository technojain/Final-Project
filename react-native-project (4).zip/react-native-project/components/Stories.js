import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text } from 'react-native-elements';
import React from 'react';
import { styles } from './style';

const Stories = ({ navigation, data }) => {
  const renderItem = ({ item }) => (
    <Button
      title={item.title}
      buttonStyle={{
        width: '100%',
        justifyContent: 'flex-start',
      }}
      titleStyle={{ color: '#000000' }}
      containerStyle={styles.item}
      onPress={() => navigation.navigate(`story${item.id}`)}
    />
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Stories List</Text>
      <FlatList
        style={{ width: '100%' }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

export default Stories;
